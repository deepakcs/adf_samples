package com.dsid.soap.service;

import com.dsid.soap.service.entities.Departments;

import java.util.List;

import javax.ejb.Local;

@Local
public interface SessionFacadeLocal {
    Object queryByRange(String jpqlStmt, int firstResult, int maxResults);

    Departments persistDepartments(Departments departments);

    Departments mergeDepartments(Departments departments);

    void removeDepartments(Departments departments);

    List<Departments> getDepartmentsFindAll();
}
