package com.dsid.soap.service.entities;

import java.io.Serializable;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

@Entity
@NamedQueries( { @NamedQuery(name = "Departments.findAll", query = "select o from Departments o") })
public class Departments implements Serializable {
    @Id
    @Column(name = "DEPARTMENT_ID", nullable = false)
    private BigDecimal departmentId;
    @Column(name = "DEPARTMENT_NAME", nullable = false, length = 100)
    private String departmentName;
    @Column(name = "LOCATION_NAME", length = 100)
    private String locationName;
    @Column(length = 50)
    private String status;

    public Departments() {
    }

    public Departments(BigDecimal departmentId, String departmentName, String locationName, String status) {
        this.departmentId = departmentId;
        this.departmentName = departmentName;
        this.locationName = locationName;
        this.status = status;
    }

    public BigDecimal getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(BigDecimal departmentId) {
        this.departmentId = departmentId;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    public String getLocationName() {
        return locationName;
    }

    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
