package application;

import java.sql.Connection;

import java.sql.SQLException;

import oracle.adfmf.framework.api.AdfmfJavaUtilities;

public class DBConnectionFactory {
    protected static Connection conn = null;

    public DBConnectionFactory() {
        super();
    }

    /**
     * Connect to the SQLite database
     * @return
     * @throws Exception
     */
    public static Connection getConnection() throws Exception {
        if (conn == null) {
            try {
                // ApplicationDirectory returns the private read-write sandbox area
                // of the mobile device's file system that this application can access.
                // This is where the database is created
                String Dir = AdfmfJavaUtilities.getDirectoryPathRoot(AdfmfJavaUtilities.ApplicationDirectory);
                String connStr = "jdbc:sqlite:" + Dir + "/SYNC.db";

                // If the database does not exist, a new database is automatically
                // created when the SQLite JDBC connection is created
                conn = new SQLite.JDBCDataSource(connStr).getConnection();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return conn;
    }
}
