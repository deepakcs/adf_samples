package com.dsid.model.dc;


import application.DBConnectionFactory;

import com.dsid.model.entities.Departments;

import com.sun.util.logging.Level;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;

import javax.el.ValueExpression;

import oracle.adfmf.framework.api.AdfmfContainerUtilities;
import oracle.adfmf.framework.api.AdfmfJavaUtilities;
import oracle.adfmf.framework.api.GenericTypeBeanSerializationHelper;
import oracle.adfmf.framework.model.AdfELContext;
import oracle.adfmf.java.beans.PropertyChangeListener;
import oracle.adfmf.java.beans.PropertyChangeSupport;
import oracle.adfmf.java.beans.ProviderChangeListener;
import oracle.adfmf.java.beans.ProviderChangeSupport;
import oracle.adfmf.util.GenericType;
import oracle.adfmf.util.Utility;
import oracle.adfmf.util.logging.Trace;


public class DepartmentsDC {
    private static final String STATUS_MODIFIED = "MODIFIED"; // Indicates row is modified
    private static final String STATUS_DELETED = "DELETED"; // Indicates row is deleted
    private static final String STATUS_NEWLY_CREATED = "NEWLY_CREATED"; // Indicates row is created
    private static final String STATUS_NOT_CHANGED = "NOT_CHANGED"; // Indicates row is not changed

    private static List s_departments = null;
    private Departments editDepartments = new Departments();

    private transient ProviderChangeSupport providerChangeSupport = new ProviderChangeSupport(this);
    private transient PropertyChangeSupport propertyChangeSupport = new PropertyChangeSupport(this);

    public DepartmentsDC() {
        super();
    }

    public void addPropertyChangeListener(PropertyChangeListener l) {
        propertyChangeSupport.addPropertyChangeListener(l);
    }

    public void removePropertyChangeListener(PropertyChangeListener l) {
        propertyChangeSupport.removePropertyChangeListener(l);
    }

    public void addProviderChangeListener(ProviderChangeListener l) {
        providerChangeSupport.addProviderChangeListener(l);
    }

    public void removeProviderChangeListener(ProviderChangeListener l) {
        providerChangeSupport.removeProviderChangeListener(l);
    }

    /**
     * Query all departments from local DB.
     * @return Collection of Departments
     */
    public Departments[] getDepartmentsFindAll() {
        Trace.log(Utility.FrameworkLogger, Level.INFO, this.getClass(), "getDepartmentsFindAll",
                  "Executing getDepartmentsFindAll Method");
        Departments d[] = null;
        try {
            Connection conn = DBConnectionFactory.getConnection();
            s_departments = new ArrayList();
            conn.setAutoCommit(false);
            PreparedStatement pStmt =
                conn.prepareStatement("SELECT DEPARTMENT_ID, DEPARTMENT_NAME, LOCATION_NAME, STATUS from DEPARTMENTS WHERE STATUS IN(?, ?, ?)");
            pStmt.setString(1, STATUS_NEWLY_CREATED);
            pStmt.setString(2, STATUS_MODIFIED);
            pStmt.setString(3, STATUS_NOT_CHANGED);
            ResultSet rs = pStmt.executeQuery();
            while (rs.next()) {
                Departments deptRes =
                    new Departments(rs.getInt("DEPARTMENT_ID"), rs.getString("DEPARTMENT_NAME"), rs.getString("LOCATION_NAME"),
                                    rs.getString("STATUS"));
                s_departments.add(deptRes);
            }
        } catch (SQLException e) {
            Trace.log(Utility.FrameworkLogger, Level.SEVERE, this.getClass(), "getDepartmentsFindAll", e.getMessage());
        } catch (Exception e) {
            Trace.log(Utility.FrameworkLogger, Level.SEVERE, this.getClass(), "getDepartmentsFindAll", e.getMessage());
        }
        d = (Departments[])s_departments.toArray(new Departments[s_departments.size()]);
        return d;
    }

    /**
     * Method will create new deptartment object instance
     */
    public void AddDepartment() {
        Trace.log(Utility.FrameworkLogger, Level.INFO, this.getClass(), "AddDepartment",
                  "Executing AddDepartment Method");
        setEditDepartments(new Departments(0, "", "", STATUS_NEWLY_CREATED));
    }

    /**
     * Method will create new deptartment object instance with populating values
     */
    public void EditDepartment(int departmentId, String departmentName, String locationName) {
        Trace.log(Utility.FrameworkLogger, Level.INFO, this.getClass(), "EditDepartment",
                  "Executing EditDepartment Method");
        setEditDepartments(new Departments(departmentId, departmentName, locationName, STATUS_MODIFIED));
    }

    /**
     * Method will commit the details of newly created department object
     * @return
     */
    private boolean addDepartmentToDB() {
        Trace.log(Utility.FrameworkLogger, Level.INFO, this.getClass(), "AddDepartmentToDB",
                  "Executing AddDepartmentToDB Method");
        boolean result = false;
        try {
            Connection conn = DBConnectionFactory.getConnection();
            conn.setAutoCommit(false);
            String insertSQL =
                "Insert into DEPARTMENTS (DEPARTMENT_ID, DEPARTMENT_NAME, LOCATION_NAME, STATUS) values (?,?,?,?)";
            PreparedStatement pStmt = conn.prepareStatement(insertSQL);
            pStmt.setInt(1, editDepartments.getDepartmentId());
            pStmt.setString(2, editDepartments.getDepartmentName());
            pStmt.setString(3, editDepartments.getLocationName());
            pStmt.setString(4, editDepartments.getStatus());
            pStmt.execute();
            conn.commit();
            result = true;
        } catch (SQLException e) {
            Trace.log(Utility.FrameworkLogger, Level.SEVERE, this.getClass(), "AddDepartmentToDB", e.getMessage());
        } catch (Exception e) {
            Trace.log(Utility.FrameworkLogger, Level.SEVERE, this.getClass(), "AddDepartmentToDB", e.getMessage());
        }
        return result;
    }

    /**
     * Method will commit the details of edited department object
     * @return
     */
    private boolean updateDepartmentToDB() {
        Trace.log(Utility.FrameworkLogger, Level.INFO, this.getClass(), "updateDepartmentToDB",
                  "Executing updateDepartmentToDB Method");
        boolean result = false;
        try {
            Connection conn = DBConnectionFactory.getConnection();
            conn.setAutoCommit(false);
            String updateSQL =
                "UPDATE DEPARTMENTS SET DEPARTMENT_NAME=?, LOCATION_NAME=?, STATUS=? WHERE DEPARTMENT_ID=?";
            PreparedStatement pStmt = conn.prepareStatement(updateSQL);
            pStmt.setString(1, editDepartments.getDepartmentName());
            pStmt.setString(2, editDepartments.getLocationName());
            pStmt.setString(3, editDepartments.getStatus());
            pStmt.setInt(4, editDepartments.getDepartmentId());
            pStmt.execute();
            conn.commit();
            result = true;
        } catch (SQLException e) {
            Trace.log(Utility.FrameworkLogger, Level.SEVERE, this.getClass(), "updateDepartmentToDB", e.getMessage());
        } catch (Exception e) {
            Trace.log(Utility.FrameworkLogger, Level.SEVERE, this.getClass(), "updateDepartmentToDB", e.getMessage());
        }
        return result;
    }

    /**
     * Synchronization of data from online to offline
     */
    private void syncDeptDataUsingWebService() {
        Trace.log(Utility.FrameworkLogger, Level.INFO, this.getClass(), "syncDeptDataUsingWebService",
                  "Executing syncDeptDataUsingWebService Method");
        try {
            Connection conn = DBConnectionFactory.getConnection();
            conn.setAutoCommit(false);
            List namesList = new ArrayList(1);
            List paramsList = new ArrayList(1);
            List typesList = new ArrayList(1);
            if (editDepartments.getStatus().equals(STATUS_NEWLY_CREATED)) {
                editDepartments.setStatus(STATUS_NOT_CHANGED);
                GenericType gtDept =
                    GenericTypeBeanSerializationHelper.toGenericType("EJBServiceWSDC.Types.persistDepartments.arg0",
                                                                     editDepartments);
                namesList.add("arg0");
                paramsList.add(gtDept);
                typesList.add(Object.class);
                AdfmfJavaUtilities.invokeDataControlMethod("EJBServiceWSDC", null, "persistDepartments", namesList,
                                                           paramsList, typesList);
                //Once the data sync with online, change the status for the row as STATUS_NOT_CHANGED
                PreparedStatement pStmt =
                    conn.prepareStatement("UPDATE DEPARTMENTS SET STATUS=? WHERE DEPARTMENT_ID=?");
                pStmt.setString(1, STATUS_NOT_CHANGED);
                pStmt.setInt(2, editDepartments.getDepartmentId());
                pStmt.execute();
                conn.commit();
            } else if (editDepartments.getStatus().equals(STATUS_MODIFIED)) {
                editDepartments.setStatus(STATUS_NOT_CHANGED);
                GenericType gtDept =
                    GenericTypeBeanSerializationHelper.toGenericType("EJBServiceWSDC.Types.mergeDepartments.arg0",
                                                                     editDepartments);
                namesList.add("arg0");
                paramsList.add(gtDept);
                typesList.add(Object.class);
                AdfmfJavaUtilities.invokeDataControlMethod("EJBServiceWSDC", null, "mergeDepartments", namesList,
                                                           paramsList, typesList);
                //Once the data sync with online, change the status for the row as STATUS_NOT_CHANGED
                PreparedStatement pStmt =
                    conn.prepareStatement("UPDATE DEPARTMENTS SET STATUS=? WHERE DEPARTMENT_ID=?");
                pStmt.setString(1, STATUS_NOT_CHANGED);
                pStmt.setInt(2, editDepartments.getDepartmentId());
                pStmt.execute();
                conn.commit();
            } else if (editDepartments.getStatus().equals(STATUS_DELETED)) {
                GenericType gtDept =
                    GenericTypeBeanSerializationHelper.toGenericType("EJBServiceWSDC.Types.removeDepartments.arg0",
                                                                     editDepartments);
                namesList.add("arg0");
                paramsList.add(gtDept);
                typesList.add(Object.class);
                AdfmfJavaUtilities.invokeDataControlMethod("EJBServiceWSDC", null, "removeDepartments", namesList,
                                                           paramsList, typesList);
                //Once the data sync with online, change the status for the row as STATUS_NOT_CHANGED
                PreparedStatement pStmt = conn.prepareStatement("DELETE from DEPARTMENTS WHERE DEPARTMENT_ID=?");
                pStmt.setInt(1, editDepartments.getDepartmentId());
                pStmt.execute();
                conn.commit();
            }
        } catch (SQLException e) {
            Trace.log(Utility.FrameworkLogger, Level.SEVERE, this.getClass(), "syncDeptDataUsingWebService",
                      e.getStackTrace());
        } catch (Exception e) {
            Trace.log(Utility.FrameworkLogger, Level.SEVERE, this.getClass(), "syncDeptDataUsingWebService",
                      e.getStackTrace());
        }
    }

    /**
     * Method will call the save the department
     * Call PropertyChangeSupport listener to push data changes to the UI
     */
    public void saveDepartment() {
        Trace.log(Utility.FrameworkLogger, Level.INFO, this.getClass(), "saveDepartment",
                  "Executing saveDepartment Method");
        // Check the row is newly created then call addDepartmentToDB
        if (editDepartments.getStatus().equals(STATUS_NEWLY_CREATED)) {
            if (addDepartmentToDB()) {
                Departments newDepartment = new Departments(editDepartments);
                s_departments.add(0, newDepartment);
                providerChangeSupport.fireProviderCreate("departments", newDepartment.getKey(), newDepartment);
            }
        }
        // Check the row is modified then call updateDepartmentToDB
        if (editDepartments.getStatus().equals(STATUS_MODIFIED)) {
            if (updateDepartmentToDB()) {
                providerChangeSupport.fireProviderRefresh("departments");
            }
        }
        // Check the row is deleted then call updateDepartmentToDB
        if (editDepartments.getStatus().equals(STATUS_DELETED)) {
            if (updateDepartmentToDB()) {
                providerChangeSupport.fireProviderDelete("departments", editDepartments.getKey());
            }
        }
        // Check for the Auto Sync
        ValueExpression syncSettingVal =
            AdfmfJavaUtilities.getValueExpression("#{preferenceScope.application.Synchronization.AutoSync}",
                                                  String.class);
        String syncSetting = (String)syncSettingVal.getValue(AdfmfJavaUtilities.getAdfELContext());
        if (syncSetting.equals("true")) {
            if (getNetWorkStatus().equals("true")) {
                syncDeptDataUsingWebService();
            }
        }
    }

    /**
     * Method will check the network status
     * @return networkStatus
     */
    public String getNetWorkStatus() {
        ValueExpression networkStatusVal =
            AdfmfJavaUtilities.getValueExpression("#{applicationScope.networkStatus}", String.class);
        return (String)networkStatusVal.getValue(AdfmfJavaUtilities.getAdfELContext());
    }

    public void setEditDepartments(Departments editDepartments) {
        this.editDepartments = editDepartments;
    }

    public Departments getEditDepartments() {
        return editDepartments;
    }
}
