package com.dsid.model.dc;


import application.DBConnectionFactory;

import com.dsid.model.entities.Departments;

import com.sun.util.logging.Level;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;

import javax.el.ValueExpression;

import oracle.adfmf.framework.api.AdfmfJavaUtilities;
import oracle.adfmf.framework.api.GenericTypeBeanSerializationHelper;
import oracle.adfmf.framework.exception.AdfInvocationException;
import oracle.adfmf.util.GenericType;
import oracle.adfmf.util.Utility;
import oracle.adfmf.util.logging.Trace;


public class SynchronizationDC {
    private static final String STATUS_MODIFIED = "MODIFIED"; // Indicates row is modified
    private static final String STATUS_DELETED = "DELETED"; // Indicates row is deleted
    private static final String STATUS_NEWLY_CREATED = "NEWLY_CREATED"; // Indicates row is created
    private static final String STATUS_NOT_CHANGED = "NOT_CHANGED"; // Indicates row is not changed

    public SynchronizationDC() {
        super();
    }

    /**
     * Synchronization of data from online to offline
     * Pull all the data from online server and store in local DB
     */
    public void syncDataFromOnlineToOffline() {
        Trace.log(Utility.FrameworkLogger, Level.INFO, this.getClass(), "syncDataFromOnlineToOffline",
                  "Executing syncDataFromOnlineToOffline Method");
        try {
            GenericType departmentsList =
                (GenericType)AdfmfJavaUtilities.invokeDataControlMethod("EJBServiceWSDC", null,
                                                                        "getDepartmentsFindAll", new ArrayList(),
                                                                        new ArrayList(), new ArrayList());
            if (departmentsList != null) {
                for (int i = 0; i < departmentsList.getAttributeCount(); i++) {
                    GenericType row = (GenericType)departmentsList.getAttribute(i);
                    Departments departments =
                        (Departments)GenericTypeBeanSerializationHelper.fromGenericType(Departments.class, row);
                    Connection conn = DBConnectionFactory.getConnection();
                    conn.setAutoCommit(false);
                    String insertSQL =
                        "Insert into DEPARTMENTS (DEPARTMENT_ID, DEPARTMENT_NAME, LOCATION_NAME, STATUS) values (?,?,?,?)";
                    System.out.println(insertSQL);
                    PreparedStatement pStmt = conn.prepareStatement(insertSQL);
                    pStmt.setInt(1, departments.getDepartmentId());
                    pStmt.setString(2, departments.getDepartmentName());
                    pStmt.setString(3, departments.getLocationName());
                    pStmt.setString(4, departments.getStatus());
                    pStmt.execute();
                    conn.commit();
                }
            }
        } catch (AdfInvocationException e) {
            Trace.log(Utility.FrameworkLogger, Level.SEVERE, this.getClass(), "syncDataFromOnlineToOffline",
                      e.getMessage());
        } catch (Exception e) {
            Trace.log(Utility.FrameworkLogger, Level.SEVERE, this.getClass(), "syncDataFromOnlineToOffline",
                      e.getMessage());
        }
    }

    /**
     * Synchronization of data from offline to online
     */
    public void syncDataFromOfflineToOnline() {
        Trace.log(Utility.FrameworkLogger, Level.INFO, this.getClass(), "syncDataFromOfflineToOnline",
                  "Executing syncDataFromOfflineToOnline Method");
        try {
            Connection conn = DBConnectionFactory.getConnection();
            conn.setAutoCommit(false);
            PreparedStatement pStmt =
                conn.prepareStatement("SELECT DEPARTMENT_ID, DEPARTMENT_NAME, LOCATION_NAME, STATUS from DEPARTMENTS WHERE STATUS IN (?, ?, ?)");
            pStmt.setString(1, STATUS_NEWLY_CREATED);
            pStmt.setString(2, STATUS_MODIFIED);
            pStmt.setString(3, STATUS_DELETED);
            ResultSet rs = pStmt.executeQuery();
            while (rs.next()) {
                List namesList = new ArrayList(1);
                List paramsList = new ArrayList(1);
                List typesList = new ArrayList(1);

                Departments dept = new Departments();
                dept.setDepartmentId(rs.getInt("DEPARTMENT_ID"));
                dept.setDepartmentName(rs.getString("DEPARTMENT_NAME"));
                dept.setLocationName(rs.getString("LOCATION_NAME"));
                dept.setStatus(STATUS_NOT_CHANGED);

                if (rs.getString("STATUS").equals(STATUS_NEWLY_CREATED)) {
                    GenericType gtDept =
                        GenericTypeBeanSerializationHelper.toGenericType("EJBServiceWSDC.Types.persistDepartments.arg0",
                                                                         dept);
                    namesList.add("arg0");
                    paramsList.add(gtDept);
                    typesList.add(Object.class);
                    AdfmfJavaUtilities.invokeDataControlMethod("EJBServiceWSDC", null, "persistDepartments", namesList,
                                                               paramsList, typesList);
                    //Once the data sync with online, change the status for the row as STATUS_NOT_CHANGED
                    PreparedStatement pStmt1 =
                        conn.prepareStatement("UPDATE DEPARTMENTS SET STATUS=? WHERE DEPARTMENT_ID=?");
                    pStmt1.setString(1, STATUS_NOT_CHANGED);
                    pStmt1.setInt(2, rs.getInt("DEPARTMENT_ID"));
                    pStmt1.execute();
                    conn.commit();
                } else if (rs.getString("STATUS").equals(STATUS_MODIFIED)) {
                    GenericType gtDept =
                        GenericTypeBeanSerializationHelper.toGenericType("EJBServiceWSDC.Types.mergeDepartments.arg0",
                                                                         dept);
                    namesList.add("arg0");
                    paramsList.add(gtDept);
                    typesList.add(Object.class);
                    AdfmfJavaUtilities.invokeDataControlMethod("EJBServiceWSDC", null, "mergeDepartments", namesList,
                                                               paramsList, typesList);
                    //Once the data sync with online, change the status for the row as STATUS_NOT_CHANGED
                    PreparedStatement pStmt1 =
                        conn.prepareStatement("UPDATE DEPARTMENTS SET STATUS=? WHERE DEPARTMENT_ID=?");
                    pStmt1.setString(1, STATUS_NOT_CHANGED);
                    pStmt1.setInt(2, rs.getInt("DEPARTMENT_ID"));
                    pStmt1.execute();
                    conn.commit();
                } else if (rs.getString("STATUS").equals(STATUS_DELETED)) {
                    GenericType gtDept =
                        GenericTypeBeanSerializationHelper.toGenericType("EJBServiceWSDC.Types.removeDepartments.arg0",
                                                                         dept);
                    namesList.add("arg0");
                    paramsList.add(gtDept);
                    typesList.add(Object.class);
                    AdfmfJavaUtilities.invokeDataControlMethod("EJBServiceWSDC", null, "removeDepartments", namesList,
                                                               paramsList, typesList);
                    //Once the data sync with online, change the status for the row as STATUS_NOT_CHANGED
                    PreparedStatement pStmt1 = conn.prepareStatement("DELETE from DEPARTMENTS WHERE DEPARTMENT_ID=?");
                    pStmt1.setInt(1, rs.getInt("DEPARTMENT_ID"));
                    pStmt1.execute();
                    conn.commit();
                }
            }
        } catch (SQLException e) {
            Trace.log(Utility.FrameworkLogger, Level.SEVERE, this.getClass(), "syncDataFromOfflineToOnline",
                      e.getMessage());
        } catch (Exception e) {
            Trace.log(Utility.FrameworkLogger, Level.SEVERE, this.getClass(), "syncDataFromOfflineToOnline",
                      e.getStackTrace());
        }
    }
}
