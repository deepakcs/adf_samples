package com.dsid.model.entities;

import java.io.Serializable;

import oracle.adfmf.java.beans.PropertyChangeListener;
import oracle.adfmf.java.beans.PropertyChangeSupport;


public class Departments implements Serializable {
    private static final long serialVersionUID = 3L;

    private int departmentId;
    private String departmentName;
    private String locationName;
    private String status;
    private transient PropertyChangeSupport propertyChangeSupport = new PropertyChangeSupport(this);

    public Departments() {
        super();
    }

    public Departments(int departmentId, String departmentName, String locationName, String status) {
        super();
        this.departmentId = departmentId;
        this.departmentName = departmentName;
        this.locationName = locationName;
        this.status = status;
    }

    public Departments(Departments newDepartments) {
        setDepartmentId(newDepartments.getDepartmentId());
        setDepartmentName(newDepartments.getDepartmentName());
        setLocationName(newDepartments.getLocationName());
        setStatus(newDepartments.getStatus());
    }

    public String getKey() {
        Integer i = new Integer(departmentId);
        return i.toString();
    }

    public void addPropertyChangeListener(PropertyChangeListener l) {
        propertyChangeSupport.addPropertyChangeListener(l);
    }

    public void removePropertyChangeListener(PropertyChangeListener l) {
        propertyChangeSupport.removePropertyChangeListener(l);
    }

    public void setDepartmentId(int departmentId) {
        int oldDepartmentId = this.departmentId;
        this.departmentId = departmentId;
        propertyChangeSupport.firePropertyChange("departmentId", oldDepartmentId, departmentId);
    }

    public int getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentName(String departmentName) {
        String oldDepartmentName = this.departmentName;
        this.departmentName = departmentName;
        propertyChangeSupport.firePropertyChange("departmentName", oldDepartmentName, departmentName);
    }

    public String getDepartmentName() {
        return departmentName;
    }


    public void setLocationName(String locationName) {
        String oldLocationName = this.locationName;
        this.locationName = locationName;
        propertyChangeSupport.firePropertyChange("locationName", oldLocationName, locationName);
    }

    public String getLocationName() {
        return locationName;
    }

    public void setStatus(String status) {
        String oldStatus = this.status;
        this.status = status;
        propertyChangeSupport.firePropertyChange("status", oldStatus, status);
    }

    public String getStatus() {
        return status;
    }
}
