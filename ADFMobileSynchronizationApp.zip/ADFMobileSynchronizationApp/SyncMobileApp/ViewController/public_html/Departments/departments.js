(function () {
    if (!window.application)
        window.application = {
        };

    /**
     * Method to check the network status
     */
    application.checkConnection = function () {
        var networkState = navigator.network.connection.type;
        var states = {
        };
        states[Connection.UNKNOWN] = 'Unknown connection';
        states[Connection.ETHERNET] = 'Ethernet connection';
        states[Connection.WIFI] = 'WiFi connection';
        states[Connection.CELL_2G] = 'Cell 2G connection';
        states[Connection.CELL_3G] = 'Cell 3G connection';
        states[Connection.CELL_4G] = 'Cell 4G connection';
        states[Connection.NONE] = 'No network connection';
        if (networkState == Connection.NONE || networkState == Connection.UNKNOWN) {
            navigator.notification.alert('No Network Connection', alertDismissed, 'Network Status', 'OK');
        }
        else {
            var syncType = arguments[0];
            if (syncType == 'fullSync') {
                adf.mf.api.invokeMethod("mobile.DepartmentsBean", "syncDataFromOfflineToOnline", onSyncSuccess, onFail);
            }
            if (syncType == 'partialSync') {
                adf.mf.api.invokeMethod("mobile.DepartmentsBean", "saveDepartment", "true", onSuccess, onFail);
            }
        }
    }

    // alert dialog dismissed
    function alertDismissed() {
        // do something
    }

    function onSyncSuccess(param) {
        navigator.notification.alert('Data Synchronized Successfully', alertDismissed, 'Synchronization', 'OK');
    }

    function onSuccess(param) {
        //To do code after failure
    }

    function onFail() {
        //To do code after failure
    }

})();