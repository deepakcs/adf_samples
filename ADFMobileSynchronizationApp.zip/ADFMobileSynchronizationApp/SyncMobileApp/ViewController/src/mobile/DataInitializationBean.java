package mobile;


import com.sun.util.logging.Level;

import java.util.ArrayList;

import oracle.adfmf.amx.event.ActionEvent;
import oracle.adfmf.framework.api.AdfmfContainerUtilities;
import oracle.adfmf.framework.api.AdfmfJavaUtilities;
import oracle.adfmf.framework.exception.AdfInvocationException;
import oracle.adfmf.util.Utility;
import oracle.adfmf.util.logging.Trace;


public class DataInitializationBean {
    public DataInitializationBean() {
    }

    /**
     * Method to check network connection
     * Call the javascript method to check network connection using cordova api
     * @param actionEvent
     */
    public void checkNetworkConnection(ActionEvent actionEvent) {
        AdfmfContainerUtilities.invokeContainerJavaScriptFunction("DataInitialization", "application.checkConnection",
                                                                  new Object[] { });
    }

    /**
     * Method to Start Data Initialization
     * Go to Departments feature
     * This method will be called only once when the application loads for first time
     */
    public void startDataInitialization() {
        try {
            AdfmfJavaUtilities.invokeDataControlMethod("SynchronizationDC", null, "syncDataFromOnlineToOffline",
                                                       new ArrayList(), new ArrayList(), new ArrayList());
            AdfmfContainerUtilities.gotoFeature("Departments");
        } catch (AdfInvocationException e) {
            Trace.log(Utility.FrameworkLogger, Level.SEVERE, this.getClass(), "dataInitialization", e.getMessage());
        }
    }
}
