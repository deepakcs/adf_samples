package mobile;

import com.sun.util.logging.Level;

import java.util.ArrayList;

import javax.el.ValueExpression;

import oracle.adfmf.amx.event.ActionEvent;
import oracle.adfmf.framework.api.AdfmfContainerUtilities;
import oracle.adfmf.framework.api.AdfmfJavaUtilities;
import oracle.adfmf.framework.exception.AdfInvocationException;
import oracle.adfmf.util.Utility;
import oracle.adfmf.util.logging.Trace;

public class DepartmentsBean {
    public DepartmentsBean() {
    }

    /**
     * Method to check network connection
     * Javascript method will use cordova api to check network status
     * @param actionEvent
     */
    public void checkNetworkConnectionAction(ActionEvent actionEvent) {
        AdfmfContainerUtilities.invokeContainerJavaScriptFunction("Departments", "application.checkConnection",
                                                                  new Object[] { "fullSync" });
    }

    /**
     * Synchronization of data from offline to online
     */
    public void syncDataFromOfflineToOnline() {
        try {
            AdfmfJavaUtilities.invokeDataControlMethod("SynchronizationDC", null, "syncDataFromOfflineToOnline",
                                                       new ArrayList(), new ArrayList(), new ArrayList());

        } catch (AdfInvocationException e) {
            Trace.log(Utility.FrameworkLogger, Level.SEVERE, this.getClass(), "dataInitialization", e.getStackTrace());
        }
    }


    /**
     * Method will check the Synchronization setting preference set to Auto sync
     * Auto Sync - true, call method to check network connection and Javascript method will use cordova api to check network status
     * Auto Sync - false, call the saveDepartment method to store the data to local DB
     * @param actionEvent
     */
    public void saveDepartmentAction(ActionEvent actionEvent) {
        ValueExpression syncSettingVal =
            AdfmfJavaUtilities.getValueExpression("#{preferenceScope.application.Synchronization.AutoSync}",
                                                  String.class);
        String syncSetting = (String)syncSettingVal.getValue(AdfmfJavaUtilities.getAdfELContext());
        if (syncSetting.equals("true")) {
            AdfmfContainerUtilities.invokeContainerJavaScriptFunction("Departments", "application.checkConnection",
                                                                      new Object[] { "partialSync" });
        } else {
            try {
                AdfmfJavaUtilities.invokeDataControlMethod("DepartmentsDC", null, "saveDepartment", new ArrayList(),
                                                           new ArrayList(), new ArrayList());
            } catch (AdfInvocationException e) {
                Trace.log(Utility.FrameworkLogger, Level.SEVERE, this.getClass(), "saveDepartment",
                          " Departments Bean :" + e.getStackTrace());
            }
        }
    }

    /**
     * Method will first set the network status and
     * Call the saveDepartment method
     * @param networkStatus
     */
    public void saveDepartment(String networkStatus) {
        ValueExpression ve = AdfmfJavaUtilities.getValueExpression("#{applicationScope.networkStatus}", String.class);
        ve.setValue(AdfmfJavaUtilities.getAdfELContext(), networkStatus);
        try {
            AdfmfJavaUtilities.invokeDataControlMethod("DepartmentsDC", null, "saveDepartment", new ArrayList(),
                                                       new ArrayList(), new ArrayList());
        } catch (AdfInvocationException e) {
            Trace.log(Utility.FrameworkLogger, Level.SEVERE, this.getClass(), "saveDepartment",
                      " Departments Bean :" + e.getStackTrace());
        }
    }
}
